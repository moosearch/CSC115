//Wesley Chow
//Assignment 5
//Due November 30, 2012
//Class
public abstract class Compound{
    Rectangle smallRect;
    Oval oval;
    Square squa;
    DrawingFrame drawer;

    public Compound(){
        drawer = new DrawingFrame(400,400);
    }


}