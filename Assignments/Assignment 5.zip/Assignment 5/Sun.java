//Wesley Chow
//Assignment 5
//Due November 30, 2012
//Class
public class Sun extends Compound{

    public Sun(int x, int y, int radius){
        Circle sun = new Circle(x, y, radius);
    }

}